import { Component } from "react";

class ImageComponent extends Component {
  render() {
    return (
      <img
        src={this.props.source}
        alt={this.props.altText}
        style={{
          width: "60%",
          height: "auto",
          border: "1px solid blue",
          borderRadius: "10px 30px",
        }}
      />
    );
  }
}

export default ImageComponent;
