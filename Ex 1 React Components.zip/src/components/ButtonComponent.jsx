const ButtonComponent = (props) => {
  return (
    <button className="btn"
      style={{
        color: "green",
        border: "1px solid black",
        borderRadius: "10px 30px",
        width: "15%",
        height: "auto"
      }}
    >
      {props.txt}
    </button>
  );
};

export default ButtonComponent;
