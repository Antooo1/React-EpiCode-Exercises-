import './App.css';
import ImageComponent from './components/ImageComponent';
import ButtonComponent from './components/ButtonComponent';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <ButtonComponent txt="I am here to be clicked"/>
        <ImageComponent source="https://www.freewebsolution.it/wp-content/uploads/2021/03/React-Hooks-guida.jpg" altText="Ops! It meant to be a beautiful pic"/>
      </header>
    </div>
    
  );
}

export default App;
